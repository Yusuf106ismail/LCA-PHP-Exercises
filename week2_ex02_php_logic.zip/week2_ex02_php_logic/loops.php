<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>TechVibe - Loops</title>
</head>
<body>
    <h1>TechVibe - Loops & Iteration</h1>

    <h2>1. For Loop (0 to 10)</h2>
    <?php
    for ($i = 0; $i <= 10; $i++) {
        echo "<p>i is equal to {$i}</p>";
    }
    ?>

    <h2>2. Foreach Loop (South African Cities)</h2>
    <?php
    $cities = ["Cape Town", "Johannesburg", "Durban", "Gqeberha", "Pretoria"];

    foreach ($cities as $city) {
        echo "<p>{$city}</p>";
    }
    ?>

    <h2>3. While Loop (Countdown 10 to 0)</h2>
    <?php
    $count = 10;
    while ($count >= 0) {
        echo "<p>X is equal to: {$count}</p>";
        $count--;
    }
    ?>

    <h2>4. Do-While Loop</h2>
    <?php
    $counter = 6;
    
    // Trainee Observation:
    // A do-while loop ALWAYS executes its code block at least once before testing the condition.
    // Even though $counter starts at 6 (which makes $counter <= 5 FALSE), the block runs once,
    // outputting 6, and then terminates.
    
    do {
        echo "<p>Do-While Counter value: {$counter}</p>";
        $counter++;
    } while ($counter <= 5);
    ?>
    <!-- Trainee Note Display -->
    <p><em>Observation Note: The do-while loop executes the body first before checking the condition ($counter &lt;= 5). Therefore, it outputted 6 once even though 6 is greater than 5.</em></p>
</body>
</html>

