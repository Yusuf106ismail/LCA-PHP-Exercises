<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>TechVibe - Conditionals & Operators</title>
</head>
<body>
    <h1>TechVibe - Conditionals & Operators</h1>

    <h2>1. Budget Calculator</h2>
    <?php
    $totalBudget = 5000;
    $groceries = 1500;
    $transport = 800;
    $entertainment = 500;

    $totalExpenses = $groceries + $transport + $entertainment;
    $remainingBalance = $totalBudget - $totalExpenses;

    echo "<p>Total Budget: R{$totalBudget}</p>";
    echo "<p>Total Expenses: R{$totalExpenses}</p>";
    echo "<p><strong>Remaining Balance: R{$remainingBalance}</strong></p>";
    ?>

    <h2>2. Age Category Checker</h2>
    <?php
    $age = 22;

    if ($age < 12) {
        $category = "Child";
    } elseif ($age >= 13 && $age <= 17) {
        $category = "Teen";
    } elseif ($age >= 18 && $age <= 64) {
        $category = "Adult";
    } else {
        $category = "Senior";
    }

    echo "<p>Age: {$age} &mdash; Category: <strong>{$category}</strong></p>";
    ?>

    <h2>3. Simple Interest Calculator</h2>
    <?php
    $principal = 10000;
    $rate = 0.05; // 5%
    $years = 3;

    $interest = $principal * $rate * $years;
    $totalAmount = $principal + $interest;

    echo "<p>Principal: R{$principal}</p>";
    echo "<p>Interest Earned (3 years at 5%): R{$interest}</p>";
    echo "<p><strong>Total Amount: R{$totalAmount}</strong></p>";
    ?>

    <h2>4. Voter Eligibility Check</h2>
    <?php
    $voterAge = 24;
    $isRegistered = true;

    if ($voterAge >= 18 && $voterAge <= 35 && $isRegistered) {
        echo "<p>Status: <strong>Eligible Youth Voter</strong></p>";
    } else {
        echo "<p>Status: <strong>Not Eligible</strong></p>";
    }
    ?>
</body>
</html>

