<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>TechVibe - Functions</title>
</head>
<body>
    <h1>TechVibe - Reusable Functions</h1>

    <h2>1. printGreeting() Function</h2>
    <?php
    function printGreeting($name) {
        echo "<p>Hello, {$name}! Welcome to the TechVibe Junior Developer Programme.</p>";
    }

    printGreeting("Yusuf");
    ?>

    <h2>2. multiply() Function</h2>
    <?php
    function multiply($a, $b) {
        return $a * $b;
    }

    $result = multiply(8, 12);
    echo "<p>8 &times; 12 = <strong>{$result}</strong></p>";
    ?>

    <h2>3. arrayLooper() Function</h2>
    <?php
    function arrayLooper($array) {
        foreach ($array as $item) {
            echo "<p>{$item}</p>";
        }
    }

    $fruits = ["Mango", "Banana", "Marula", "Guava", "Pineapple"];
    arrayLooper($fruits);
    ?>

    <h2>4. calculateDiscount() Function</h2>
    <?php
    function calculateDiscount($amount) {
        if ($amount > 1000) {
            $discountRate = 0.10; // 10%
        } elseif ($amount >= 500 && $amount <= 999) {
            $discountRate = 0.05; // 5%
        } elseif ($amount >= 250 && $amount <= 499) {
            $discountRate = 0.02; // 2%
        } else {
            $discountRate = 0.00; // No discount
        }

        $discountAmount = $amount * $discountRate;
        $finalAmount = $amount - $discountAmount;

        return [
            'original' => $amount,
            'percentage' => ($discountRate * 100) . "%",
            'discountAmount' => $discountAmount,
            'final' => $finalAmount
        ];
    }

    // Testing various amounts
    $testAmounts = [1200, 750, 350, 150];

    foreach ($testAmounts as $amt) {
        $res = calculateDiscount($amt);
        echo "<p>Original Amount: R{$res['original']} | Discount: {$res['percentage']} (R{$res['discountAmount']}) | <strong>Final Total: R{$res['final']}</strong></p>";
    }
    ?>
</body>
</html>

