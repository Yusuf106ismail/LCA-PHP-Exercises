<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>TechVibe - Variables & Types</title>
    <style>
        table { border-collapse: collapse; margin-top: 15px; width: 320px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        .highlight { background-color: #d1e7dd; font-weight: bold; }
    </style>
</head>
<body>

    <h2>Developer Bio & Data Types</h2>

    <?php
    $name = "Yusuf Ismail";
    $age = 22;
    $favColour = "Ice Blue";
    $favHobby = "interface design and software development";

    echo "<p>Hello! I am <strong>{$name}</strong>, a <strong>{$age}</strong>-year-old developer at TechVibe. My favourite colour is <strong>{$favColour}</strong>, and in my spare time, I enjoy <strong>{$favHobby}</strong>.</p>";

    echo "<hr>";

    $weightKg = 70.5;
    $heightMeters = 1.75;
    $bmi = $weightKg / ($heightMeters ** 2);
    $formattedBmi = number_format($bmi, 1);

    if ($bmi < 18.5) {
        $category = "Underweight";
    } elseif ($bmi >= 18.5 && $bmi <= 24.9) {
        $category = "Normal weight";
    } elseif ($bmi >= 25.0 && $bmi <= 29.9) {
        $category = "Overweight";
    } else {
        $category = "Obese";
    }

    echo "<h3>BMI Calculator Result</h3>";
    echo "<p>Calculated BMI: <strong>{$formattedBmi}</strong></p>";
    echo "<p>Weight Category: <strong>{$category}</strong></p>";
    ?>

    <h4>BMI Categories Breakdown</h4>
    <table>
        <tr><th>Category</th><th>BMI Range</th></tr>
        <tr class="<?php echo ($category === 'Underweight') ? 'highlight' : ''; ?>"><td>Underweight</td><td>&lt; 18.5</td></tr>
        <tr class="<?php echo ($category === 'Normal weight') ? 'highlight' : ''; ?>"><td>Normal weight</td><td>18.5 – 24.9</td></tr>
        <tr class="<?php echo ($category === 'Overweight') ? 'highlight' : ''; ?>"><td>Overweight</td><td>25.0 – 29.9</td></tr>
        <tr class="<?php echo ($category === 'Obese') ? 'highlight' : ''; ?>"><td>Obese</td><td>&ge; 30.0</td></tr>
    </table>

    <hr>

    <?php
    $floatVal = 89.75;
    $intVal = intval($floatVal);

    echo "<h3>Type Conversion with intval()</h3>";
    echo "<p>Original Float Value: <strong>{$floatVal}</strong></p>";
    echo "<p>Converted Integer Value: <strong>{$intVal}</strong></p>";

    echo "<hr>";

    $sampleInt = 42;
    $sampleFloat = 19.99;
    $sampleString = "TechVibe";
    $sampleArray = array("HTML", "CSS", "JS", "PHP");

    echo "<h3>Type Inspection using gettype()</h3>";
    echo "<ul>";
    echo "<li><code>\$sampleInt</code> ($sampleInt): <strong>" . gettype($sampleInt) . "</strong></li>";
    echo "<li><code>\$sampleFloat</code> ($sampleFloat): <strong>" . gettype($sampleFloat) . "</strong></li>";
    echo "<li><code>\$sampleString</code> (\"$sampleString\"): <strong>" . gettype($sampleString) . "</strong></li>";
    echo "<li><code>\$sampleArray</code>: <strong>" . gettype($sampleArray) . "</strong></li>";
    echo "</ul>";
    ?>

</body>
</html>

