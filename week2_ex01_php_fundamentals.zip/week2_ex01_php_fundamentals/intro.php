<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>TechVibe - PHP Fundamentals Intro</title>
</head>
<body>

    <h1><?php echo "Welcome to PHP Programming!"; ?></h1>

    <?php
    $hour = date('H');
    if ($hour < 12) {
        $greeting = "Good morning";
    } elseif ($hour < 18) {
        $greeting = "Good afternoon";
    } else {
        $greeting = "Good evening";
    }
    echo "<h2>{$greeting}, Team TechVibe!</h2>";

    $developerName = "Yusuf Ismail";
    $favLanguage = "JavaScript";
    $reason = "it powers dynamic user interfaces and pairs seamlessly with backends.";

    echo "<p>My name is <strong>{$developerName}</strong> and my favourite programming language is <strong>{$favLanguage}</strong> because {$reason}</p>";

    $num1 = 25;
    $num2 = 75;
    $sum = $num1 + $num2;
    print "<p>The sum of {$num1} and {$num2} is: <strong>{$sum}</strong></p>";

    $formattedDate = date('l, F j, Y');
    echo "<p>Today is <strong>{$formattedDate}</strong>.</p>";

    $luckyNumber = rand(1, 100);
    echo "<p>Your lucky number today is: <strong>{$luckyNumber}</strong></p>";
    ?>

</body>
</html>

