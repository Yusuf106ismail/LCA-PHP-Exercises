<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>TechVibe - Variable Scope</title>
</head>
<body>

    <h2>PHP Variable Scope Demonstration</h2>

    <?php
    $companyName = "TechVibe Digital Agency";

    function showCompany() {
        global $companyName;
        echo "<p>Inside function using <code>global</code> keyword: <strong>{$companyName}</strong></p>";
    }

    echo "<h3>1. Global Scope</h3>";
    showCompany();

    echo "<hr>";

    function testLocalScope() {
        $localMessage = "I exist only inside this function!";
        echo "<p>Inside function: <em>{$localMessage}</em></p>";
    }

    echo "<h3>2. Local Scope</h3>";
    testLocalScope();

    echo "<p>Attempting to access local variable outside function: ";
    if (!isset($localMessage)) {
        echo "<strong style='color: red;'>Undefined (Local variables cannot be accessed outside their function scope).</strong>";
    }
    echo "</p>";

    echo "<hr>";

    function trackVisits() {
        static $visitCount = 0;
        $visitCount++;
        echo "<p>Function Call Counter: <strong>Count = {$visitCount}</strong></p>";
    }

    echo "<h3>3. Static Scope (Retaining Values)</h3>";
    trackVisits();
    trackVisits();
    trackVisits();
    ?>

</body>
</html>

